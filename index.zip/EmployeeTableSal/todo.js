function createTask() {
    var i = 0;
    var task = document.getElementById("t-val").value;
    if (task === "") {
        alert("Enter some todo task");
    }
    var x = document.createElement("li");
    var t = document.createTextNode(task);
    x.appendChild(t);
    document.getElementById("to-do-list").appendChild(x);
    document.getElementById("t-val").value = "";
    var y = document.createElement("button");
    var z = document.getElementById("board");
    z.appendChild(y);
}